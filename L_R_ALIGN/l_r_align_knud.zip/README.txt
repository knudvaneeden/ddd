===

1. -To install

     1. -Take the file l_r_align_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstalll_r_align.bat

     4. -That will create a new file l_r_align_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          l_r_align.mac

2. -The .ini file is the local file 'l_r_align.ini'
    (thus not using tse.ini)


