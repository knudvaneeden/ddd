===

1. -To install

     1. -Take the file uncrash_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstalluncrash.bat

     4. -That will create a new file uncrash_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          uncrash.mac

2. -The .ini file is the local file 'uncrash.ini'
    (thus not using tse.ini)


