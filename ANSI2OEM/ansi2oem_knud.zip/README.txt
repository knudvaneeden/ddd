===

1. -To install

     1. -Take the file ansi2oem_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstallansi2oem.bat

     4. -That will create a new file ansi2oem_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          ansi2oem.mac

2. -The .ini file is the local file 'ansi2oem.ini'
    (thus not using tse.ini)


