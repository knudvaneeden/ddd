===

1. -To install

     1. -Take the file status_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstallstatus.bat

     4. -That will create a new file status_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          status.mac

2. -The .ini file is the local file 'status.ini'
    (thus not using tse.ini)


