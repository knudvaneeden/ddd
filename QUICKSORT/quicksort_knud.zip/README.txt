===

1. -To install

     1. -Take the file quicksort_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstallquicksort.bat

     4. -That will create a new file quicksort_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          quicksort.mac

2. -The .ini file is the local file 'quicksort.ini'
    (thus not using tse.ini)


