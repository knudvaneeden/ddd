1. -To install

     1. -Take the file abrev_knud.zip

     2. -And unzip it in any arbitrary directory

     3. -Then run the file zipinstallabrev.bat

     4. -That will create a new file abrev_knud.zip
         in that directory

     5. -Unzip that latest file in a new arbitrary directory

     6. -Then run the file

          abrev.mac

2. -The .ini file is the local file 'abrev.ini'
    (thus not using tse.ini)

/*
  To use:

  Type the abbreviation, and press <f12>

  Format of the abbreviation data is:
    $abbreviation1$
    text
    text
    ...
    text

    $abbreviation2$

    etc

    Last entry _must_ be terminated by a $

    Place the '~' character where the final cursor position should be.
    Each entry _must_ have the '~' character.
 */


